# Outbid Art: Architecture

Real-time auction platform for digital art. Next.js 14 (App Router) + Supabase (Postgres, Auth, Realtime, Storage) + Stripe and/or a wallet connector.

## Folder structure

```
outbid-art/
├── app/
│   ├── layout.tsx                  # fonts, dark theme, <Header/>, Toaster
│   ├── page.tsx                    # Live gallery: featured banner + filters + card grid
│   ├── auction/[id]/page.tsx       # Bidding Arena (artwork left, BiddingColumn right)
│   ├── artist/[handle]/page.tsx    # Artist profile, past sales, live drops
│   ├── create/page.tsx             # Creator portal: upload, reserve, increment, duration, royalty
│   ├── me/page.tsx                 # Wallet balance, active bids, won items, payouts
│   └── api/
│       ├── bid/route.ts            # Validates session, calls rpc('place_bid')
│       ├── autobid/route.ts        # Upserts auto_bids row
│       ├── settle/route.ts         # Cron/edge: closes ended auctions, creates payouts
│       ├── upload/route.ts         # Signed upload URL for master file (private bucket / IPFS)
│       └── stripe/webhook/route.ts # Deposit confirmations
├── components/
│   ├── LiveArtworkBidCard.tsx      # Grid card (included)
│   ├── BiddingColumn.tsx           # Right-column arena terminal (included)
│   ├── FeaturedBanner.tsx          # "Artwork of the day"
│   ├── StatsBar.tsx                # Volume, active auctions, live bidders
│   ├── FilterBar.tsx               # Medium, price, reserve met, ending soon
│   ├── Lightbox.tsx                # Full-screen zoom/pan viewer
│   └── WalletButton.tsx            # RainbowKit / Wagmi connect
├── hooks/
│   ├── useCountdown.ts             # ms-precision timer, re-syncs on endsAt change (included)
│   └── useAuctionRealtime.ts       # Supabase channel for bids + auction updates (included)
├── lib/
│   ├── types.ts                    # Shared types + formatUsd (included)
│   ├── mock-data.ts                # 6 sample auctions (included)
│   ├── sounds.ts                   # Web Audio bid/outbid/win sounds (included)
│   └── supabase/{client,server}.ts
└── supabase/
    └── schema.sql                  # Tables, place_bid(), RLS, realtime (included)
```

## How the important parts work

**Bidding is atomic.** The client never inserts into `bids`. It calls `place_bid()` (Postgres function), which locks the auction row with `FOR UPDATE`, validates the amount, inserts the bid, updates the price and highest bidder, and applies anti-sniping, all in one transaction. Two people bidding in the same millisecond are serialized; the loser gets `bid_too_low`.

**Anti-sniping lives in the database.** If `ends_at - now() <= 15s`, the function sets `ends_at = now() + 30s`. The `auctions` UPDATE is broadcast over Supabase Realtime, so every client's `useCountdown` re-targets to the new `endsAt` without any client-side logic.

**Realtime.** `bids` and `auctions` are in the `supabase_realtime` publication. Supabase Realtime is typically well under a second end to end, but whether you hit your 100ms target depends on region and load, so measure it from your users' locations before promising that number. If you need a hard guarantee, put a Socket.io/Ably layer in front and let Postgres be the source of truth.

**Clocks.** Never trust a device clock. Measure `serverOffsetMs` once on page load (server time minus client time) and pass it to `useCountdown`.

**Money is integer cents** everywhere.

## Setup

```bash
npx create-next-app@latest outbid-art --ts --tailwind --app
cd outbid-art
npm i framer-motion lucide-react @supabase/supabase-js
```

Add to `.env.local`:
```
NEXT_PUBLIC_SUPABASE_URL=...
NEXT_PUBLIC_SUPABASE_ANON_KEY=...
```

Tailwind config: add fonts for the `font-display` class used in the card, e.g.
`fontFamily: { display: ["var(--font-display)", "serif"] }`, and load a display face with `next/font`.

Run `supabase/schema.sql` in the SQL editor. Until Supabase is connected, `app/page.tsx` can run entirely on `lib/mock-data.ts` (see `demo-page.tsx`).

## Not built yet (honest gaps)

- **Auto-bid resolution.** The `auto_bids` table and UI exist, but nothing server-side bids on a user's behalf yet. Add a trigger or edge function that, after each bid, checks competing `auto_bids` and places the next increment up to each max.
- **Settlement and payouts.** `payouts` table exists; the cron job that closes auctions, checks reserve, charges the winner, and splits artist/seller/platform amounts is still to write. Use Stripe Connect for fiat payouts. For on-chain, escrow in a contract rather than a custodial balance.
- **Payments and wallet.** Balance holds, deposits, and wallet connect are stubs. Decide early whether bids are backed by pre-funded balance or card authorization; it changes the schema.
- **Master file delivery.** Keep originals in a private bucket and release a signed URL only after payment clears. Previews should be watermarked and downscaled.
- **Abuse controls.** Rate limits on `place_bid`, shill-bid detection (seller and linked accounts), and KYC for large sales. Legal and tax rules for art sales and royalties vary by jurisdiction, so get proper advice before launch.
