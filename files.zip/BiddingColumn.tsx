"use client";
import { useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { BadgeCheck, Bot, Crown, Volume2, VolumeX } from "lucide-react";
import { useCountdown } from "@/hooks/useCountdown";
import { sounds, vibrate } from "@/lib/sounds";
import { formatUsd, type Auction, type Bid } from "@/lib/types";
import { PriceTicker } from "./LiveArtworkBidCard";

interface Props {
  auction: Auction;
  /** Newest first. */
  bids: Bid[];
  currentUserId?: string;
  serverOffsetMs?: number;
  onBid: (amountCents: number) => Promise<void>;
  /** Optional: persist a proxy max server-side (see auto_bids table). */
  onSetAutoBid?: (maxCents: number | null) => Promise<void>;
}

const PRESETS_CENTS = [500, 2500, 10000];

export default function BiddingColumn({
  auction, bids, currentUserId, serverOffsetMs = 0, onBid, onSetAutoBid,
}: Props) {
  const clock = useCountdown(auction.endsAt, serverOffsetMs, auction.snipeWindowSecs);
  const [soundOn, setSoundOn] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [outbid, setOutbid] = useState(false);
  const [autoMax, setAutoMax] = useState("");
  const [autoActive, setAutoActive] = useState(false);

  const minNext = auction.currentPriceCents + auction.minIncrementCents;
  const sliderMax = minNext + 100_000; // slider covers up to +$1,000 over the minimum
  const [sliderValue, setSliderValue] = useState(minNext);
  useEffect(() => setSliderValue((v) => Math.max(v, minNext)), [minNext]);

  const iAmWinning = !!currentUserId && auction.highestBidder?.id === currentUserId;

  // ── Detect outbid / new bid / win transitions ──
  const prevWinner = useRef(auction.highestBidder?.id);
  const prevBidCount = useRef(auction.bidCount);
  const celebrated = useRef(false);

  useEffect(() => {
    const was = prevWinner.current;
    const now = auction.highestBidder?.id;
    if (auction.bidCount > prevBidCount.current) {
      if (currentUserId && was === currentUserId && now !== currentUserId) {
        setOutbid(true);
        if (soundOn) sounds.outbid();
        vibrate();
        setTimeout(() => setOutbid(false), 2500);
      } else if (now === currentUserId) {
        if (soundOn) sounds.youBid();
      } else if (soundOn) {
        sounds.newBid();
      }
    }
    prevWinner.current = now;
    prevBidCount.current = auction.bidCount;
  }, [auction.bidCount, auction.highestBidder?.id, currentUserId, soundOn]);

  const won = clock.ended && iAmWinning;
  useEffect(() => {
    if (won && !celebrated.current) {
      celebrated.current = true;
      if (soundOn) sounds.win();
    }
  }, [won, soundOn]);

  async function submit(cents: number) {
    setError(null);
    setBusy(true);
    try {
      await onBid(cents);
    } catch (e) {
      setError(e instanceof Error ? e.message.replaceAll("_", " ") : "Bid failed");
    } finally {
      setBusy(false);
    }
  }

  async function toggleAuto() {
    if (!onSetAutoBid) return;
    if (autoActive) {
      await onSetAutoBid(null);
      setAutoActive(false);
      return;
    }
    const cents = Math.round(parseFloat(autoMax || "0") * 100);
    if (cents < minNext) return setError(`Auto-bid limit must be at least ${formatUsd(minNext)}`);
    await onSetAutoBid(cents);
    setAutoActive(true);
  }

  const confetti = useMemo(
    () => Array.from({ length: 36 }, (_, i) => ({
      id: i, x: (Math.random() - 0.5) * 520, y: 120 + Math.random() * 260,
      r: Math.random() * 720, c: ["#fcd34d", "#67e8f9", "#818cf8", "#f472b6"][i % 4],
    })),
    []
  );

  return (
    <motion.section
      animate={outbid ? { x: [0, -10, 10, -8, 8, -4, 4, 0] } : { x: 0 }}
      transition={{ duration: 0.5 }}
      className={`relative space-y-5 rounded-3xl border p-5 backdrop-blur-xl
        ${outbid ? "border-rose-500 bg-rose-500/10 shadow-[0_0_48px_-6px_rgba(244,63,94,0.7)]" : "border-white/10 bg-white/[0.04]"}`}
    >
      <AnimatePresence>
        {outbid && (
          <motion.div
            role="alert"
            initial={{ opacity: 0, y: -12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
            className="rounded-xl bg-rose-600 px-4 py-2 text-center font-bold text-white"
          >
            You've been outbid. Bid again to take the lead.
          </motion.div>
        )}
      </AnimatePresence>

      {/* Price + winner spotlight */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-sm text-zinc-400">{auction.bidCount === 0 ? "Starting bid" : "Current bid"}</p>
          <PriceTicker cents={auction.currentPriceCents} className="text-4xl font-bold text-amber-300" />
          <p className="mt-1 text-xs text-zinc-400">{auction.bidCount} bids</p>
        </div>
        <div className="text-right">
          <p className="text-sm text-zinc-400">{clock.ended ? "Auction ended" : "Ends in"}</p>
          <p className={`font-mono text-2xl tabular-nums ${clock.urgent ? "animate-pulse text-rose-400" : "text-zinc-50"}`}>
            {clock.label}
          </p>
          <p className="mt-1 text-xs text-indigo-300">Bid in the last {auction.snipeWindowSecs}s, clock resets to {auction.snipeExtendToSecs}s</p>
        </div>
      </div>

      <div className="relative flex items-center gap-3 overflow-hidden rounded-2xl border border-amber-300/30 bg-gradient-to-r from-amber-300/10 to-transparent p-3">
        {auction.highestBidder ? (
          <>
            <motion.div
              key={auction.highestBidder.id}
              initial={{ scale: 0.6, rotate: -12 }} animate={{ scale: 1, rotate: 0 }}
              transition={{ type: "spring", stiffness: 300, damping: 14 }}
              className="relative"
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={auction.highestBidder.avatarUrl} alt="" className="h-12 w-12 rounded-full ring-2 ring-amber-300" />
              <Crown className="absolute -right-1 -top-2 h-5 w-5 rotate-12 text-amber-300" />
            </motion.div>
            <div>
              <p className="text-xs text-zinc-400">{clock.ended ? "Winner" : "Leading bidder"}</p>
              <p className="font-semibold">{iAmWinning ? "You" : `@${auction.highestBidder.handle}`}</p>
            </div>
          </>
        ) : (
          <p className="text-sm text-zinc-400">No bids yet. Place the first one.</p>
        )}
      </div>

      {won && (
        <div className="relative h-0">
          {confetti.map((p) => (
            <motion.span
              key={p.id}
              initial={{ x: 0, y: 0, opacity: 1, rotate: 0 }}
              animate={{ x: p.x, y: p.y, opacity: 0, rotate: p.r }}
              transition={{ duration: 1.8, ease: "easeOut" }}
              className="absolute left-1/2 top-0 h-2 w-2 rounded-sm"
              style={{ background: p.c }}
            />
          ))}
        </div>
      )}

      {/* Bidding terminal */}
      {!clock.ended && (
        <div className="space-y-3 rounded-2xl border border-white/10 bg-black/30 p-4">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold">Place a bid</h3>
            <button
              onClick={() => setSoundOn((s) => !s)}
              aria-pressed={soundOn}
              aria-label={soundOn ? "Mute sounds" : "Turn sounds on"}
              className="rounded-lg p-1.5 text-zinc-300 hover:bg-white/10 focus-visible:outline focus-visible:outline-2 focus-visible:outline-cyan-300"
            >
              {soundOn ? <Volume2 className="h-5 w-5" /> : <VolumeX className="h-5 w-5" />}
            </button>
          </div>

          <div className="grid grid-cols-3 gap-2">
            {PRESETS_CENTS.map((p) => (
              <button
                key={p}
                disabled={busy || iAmWinning}
                onClick={() => submit(auction.currentPriceCents + Math.max(p, auction.minIncrementCents))}
                className="rounded-xl border border-indigo-400/40 bg-indigo-500/15 py-2.5 font-semibold text-indigo-100 transition hover:bg-indigo-500/35 active:scale-95 disabled:opacity-40"
              >
                +{formatUsd(p)}
              </button>
            ))}
          </div>

          <div>
            <label htmlFor="bid-slider" className="mb-1 block text-xs text-zinc-400">
              Or choose an amount: <span className="font-semibold text-zinc-100">{formatUsd(sliderValue)}</span>
            </label>
            <input
              id="bid-slider" type="range"
              min={minNext} max={sliderMax} step={auction.minIncrementCents} value={sliderValue}
              onChange={(e) => setSliderValue(Number(e.target.value))}
              className="w-full accent-cyan-300"
            />
          </div>

          <button
            disabled={busy || iAmWinning}
            onClick={() => submit(sliderValue)}
            className="w-full rounded-xl bg-gradient-to-r from-indigo-500 to-cyan-400 py-3 text-lg font-extrabold text-black transition active:scale-[0.98] disabled:opacity-40"
          >
            {iAmWinning ? "You're the highest bidder" : `Bid ${formatUsd(sliderValue)}`}
          </button>

          {onSetAutoBid && (
            <div className="flex items-center gap-2 border-t border-white/10 pt-3">
              <Bot className="h-4 w-4 shrink-0 text-indigo-300" />
              <input
                inputMode="decimal" value={autoMax} disabled={autoActive}
                onChange={(e) => setAutoMax(e.target.value.replace(/[^0-9.]/g, ""))}
                placeholder="Auto-bid up to ($)"
                aria-label="Auto-bid maximum in dollars"
                className="min-w-0 flex-1 rounded-lg border border-white/10 bg-black/40 px-3 py-1.5 text-sm outline-none focus:border-cyan-300 disabled:opacity-60"
              />
              <button
                onClick={toggleAuto}
                className={`rounded-lg px-3 py-1.5 text-sm font-semibold ${autoActive ? "bg-rose-500/80" : "bg-indigo-500/60"}`}
              >
                {autoActive ? "Stop" : "Start"}
              </button>
            </div>
          )}
          {error && <p role="alert" className="text-sm text-rose-400">{error}</p>}
        </div>
      )}

      {/* Live bid feed */}
      <div>
        <h3 className="mb-2 font-semibold">Live bids</h3>
        <ul className="max-h-72 space-y-1.5 overflow-y-auto pr-1" aria-live="polite">
          <AnimatePresence initial={false}>
            {bids.map((b, i) => (
              <motion.li
                key={b.id} layout
                initial={{ opacity: 0, y: -16, scale: 0.97 }} animate={{ opacity: 1, y: 0, scale: 1 }}
                className={`flex items-center gap-3 rounded-xl px-3 py-2 text-sm ${i === 0 ? "bg-amber-300/10 ring-1 ring-amber-300/30" : "bg-white/[0.03]"}`}
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={b.bidder.avatarUrl} alt="" className="h-7 w-7 rounded-full" />
                <span className="min-w-0 flex-1 truncate">
                  @{b.bidder.handle}
                  {b.isAuto && <Bot className="ml-1 inline h-3.5 w-3.5 text-indigo-300" aria-label="Auto-bid" />}
                  {b.extendedClock && <span className="ml-2 text-xs text-indigo-300">+{auction.snipeExtendToSecs}s</span>}
                </span>
                <span className="font-semibold tabular-nums text-amber-200">{formatUsd(b.amountCents)}</span>
                <time className="w-14 text-right text-xs text-zinc-500" dateTime={b.createdAt}>
                  {new Date(b.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
                </time>
              </motion.li>
            ))}
          </AnimatePresence>
          {bids.length === 0 && <li className="text-sm text-zinc-500">Bids will appear here as they happen.</li>}
        </ul>
      </div>

      {/* Artist + provenance */}
      <div className="space-y-2 border-t border-white/10 pt-4 text-sm">
        <div className="flex items-center gap-3">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={auction.artwork.artist.avatarUrl} alt="" className="h-10 w-10 rounded-full" />
          <div>
            <p className="flex items-center gap-1.5 font-semibold">
              {auction.artwork.artist.displayName}
              {auction.artwork.artist.isVerified && <BadgeCheck className="h-4 w-4 text-cyan-300" />}
            </p>
            <p className="text-xs text-zinc-400">{auction.artwork.artist.pastSalesCount ?? 0} past sales</p>
          </div>
        </div>
        {auction.artwork.artist.bio && <p className="text-zinc-300">{auction.artwork.artist.bio}</p>}
        <dl className="grid grid-cols-2 gap-x-4 gap-y-1 text-zinc-400">
          <dt>Edition</dt><dd className="text-zinc-200">{auction.artwork.editionNumber} of {auction.artwork.editionSize}</dd>
          <dt>Resolution</dt><dd className="text-zinc-200">{auction.artwork.widthPx} × {auction.artwork.heightPx}px</dd>
          <dt>Format</dt><dd className="text-zinc-200">{auction.artwork.fileFormat}</dd>
          <dt>License</dt><dd className="text-zinc-200">{auction.artwork.licenseType}</dd>
          <dt>Certificate</dt><dd className="text-zinc-200">{auction.artwork.certificateIssued ? "Issued" : "Pending"}</dd>
          <dt>Artist royalty</dt><dd className="text-zinc-200">{auction.artwork.royaltyBps / 100}% on resale</dd>
        </dl>
      </div>
    </motion.section>
  );
}
