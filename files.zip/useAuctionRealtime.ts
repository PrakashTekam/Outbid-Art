"use client";
import { useEffect, useState, useCallback } from "react";
import { createClient } from "@supabase/supabase-js";
import type { Auction, Bid } from "@/lib/types";

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

/**
 * Subscribes to one auction. Postgres changes arrive as raw rows, so we merge
 * only the fields that change on every bid. Bidder profiles come from a lookup
 * the caller supplies (cache users client-side to avoid a query per bid).
 */
export function useAuctionRealtime(
  initialAuction: Auction,
  initialBids: Bid[],
  resolveBidder: (id: string) => Promise<Bid["bidder"]>
) {
  const [auction, setAuction] = useState(initialAuction);
  const [bids, setBids] = useState(initialBids);
  const [lastBid, setLastBid] = useState<Bid | null>(null);

  useEffect(() => {
    const channel = supabase
      .channel(`auction:${initialAuction.id}`)
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "bids", filter: `auction_id=eq.${initialAuction.id}` },
        async (payload) => {
          const row = payload.new as any;
          const bid: Bid = {
            id: row.id,
            auctionId: row.auction_id,
            bidder: await resolveBidder(row.bidder_id),
            amountCents: Number(row.amount_cents),
            isAuto: row.is_auto,
            extendedClock: row.extended_clock,
            createdAt: row.created_at,
          };
          setBids((prev) => (prev.some((b) => b.id === bid.id) ? prev : [bid, ...prev].slice(0, 100)));
          setLastBid(bid);
        }
      )
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "auctions", filter: `id=eq.${initialAuction.id}` },
        (payload) => {
          const row = payload.new as any;
          // endsAt matters most: it carries anti-sniping extensions to every client.
          setAuction((prev) => ({
            ...prev,
            currentPriceCents: Number(row.current_price_cents),
            bidCount: row.bid_count,
            endsAt: row.ends_at,
          }));
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [initialAuction.id, resolveBidder]);

  const placeBid = useCallback(
    async (amountCents: number) => {
      const { error } = await supabase.rpc("place_bid", {
        p_auction_id: initialAuction.id,
        p_amount_cents: amountCents,
      });
      if (error) throw new Error(error.message);
    },
    [initialAuction.id]
  );

  return { auction, bids, lastBid, placeBid };
}
