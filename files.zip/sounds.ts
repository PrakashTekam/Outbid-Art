"use client";

// Tiny synthesized sounds so the demo works with zero audio files.
// Replace with <audio> assets later if you want branded sounds.

let ctx: AudioContext | null = null;

function tone(freq: number, start: number, dur: number, type: OscillatorType = "square", gain = 0.06) {
  if (typeof window === "undefined") return;
  ctx ??= new (window.AudioContext || (window as any).webkitAudioContext)();
  const o = ctx.createOscillator();
  const g = ctx.createGain();
  o.type = type;
  o.frequency.value = freq;
  g.gain.setValueAtTime(gain, ctx.currentTime + start);
  g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + start + dur);
  o.connect(g).connect(ctx.destination);
  o.start(ctx.currentTime + start);
  o.stop(ctx.currentTime + start + dur);
}

export const sounds = {
  /** Someone else bid: subtle blip */
  newBid: () => tone(660, 0, 0.08, "triangle", 0.04),
  /** You bid successfully: rising arcade chirp */
  youBid: () => { tone(520, 0, 0.07); tone(780, 0.07, 0.1); },
  /** You were outbid: low double alarm */
  outbid: () => { tone(220, 0, 0.14, "sawtooth", 0.08); tone(180, 0.18, 0.2, "sawtooth", 0.08); },
  /** You won: major arpeggio */
  win: () => [523, 659, 784, 1047].forEach((f, i) => tone(f, i * 0.12, 0.3, "sine", 0.08)),
};

export function vibrate(pattern: number | number[] = [120, 60, 120]) {
  if (typeof navigator !== "undefined" && "vibrate" in navigator) navigator.vibrate(pattern);
}
