-- Outbid Art: Supabase / PostgreSQL schema
-- Run in the Supabase SQL editor, then enable Realtime on `bids` and `auctions`.

create extension if not exists "pgcrypto";

-- ───────────────────────── users ─────────────────────────
create table public.users (
  id              uuid primary key references auth.users(id) on delete cascade,
  handle          text unique not null,
  display_name    text,
  avatar_url      text,
  wallet_address  text unique,
  balance_cents   bigint not null default 0 check (balance_cents >= 0),
  is_artist       boolean not null default false,
  is_verified     boolean not null default false,   -- verified artist badge
  bio             text,
  created_at      timestamptz not null default now()
);

-- ───────────────────────── artworks ─────────────────────────
create type art_medium as enum
  ('3d_render', 'digital_painting', 'pixel_art', 'vector', 'concept_art', 'canvas_print');

create table public.artworks (
  id                 uuid primary key default gen_random_uuid(),
  artist_id          uuid not null references public.users(id),
  title              text not null,
  description        text,
  medium             art_medium not null,
  preview_url        text not null,          -- watermarked, public
  master_file_url    text,                   -- private bucket / IPFS, released on payment
  width_px           int,
  height_px          int,
  file_format        text,                   -- PNG, TIFF, SVG...
  edition_number     int not null default 1,
  edition_size       int not null default 1,
  license_type       text not null default 'personal',
  certificate_status text not null default 'pending'
                     check (certificate_status in ('pending', 'issued')),
  royalty_bps        int not null default 1000 check (royalty_bps between 0 and 5000), -- 1000 = 10%
  created_at         timestamptz not null default now()
);

-- ───────────────────────── auctions ─────────────────────────
create type auction_status as enum ('scheduled', 'live', 'settling', 'ended', 'cancelled');

create table public.auctions (
  id                  uuid primary key default gen_random_uuid(),
  artwork_id          uuid not null references public.artworks(id),
  seller_id           uuid not null references public.users(id),
  status              auction_status not null default 'live',
  starting_price_cents bigint not null check (starting_price_cents > 0),
  reserve_price_cents  bigint,
  min_increment_cents  bigint not null default 500 check (min_increment_cents > 0),
  current_price_cents  bigint not null,
  highest_bidder_id   uuid references public.users(id),
  bid_count           int not null default 0,
  starts_at           timestamptz not null default now(),
  ends_at             timestamptz not null,
  -- anti-sniping config
  snipe_window_secs   int not null default 15,
  snipe_extend_to_secs int not null default 30,
  is_featured         boolean not null default false,
  created_at          timestamptz not null default now()
);
create index auctions_live_idx on public.auctions (status, ends_at);

-- ───────────────────────── bids ─────────────────────────
create table public.bids (
  id           uuid primary key default gen_random_uuid(),
  auction_id   uuid not null references public.auctions(id) on delete cascade,
  bidder_id    uuid not null references public.users(id),
  amount_cents bigint not null check (amount_cents > 0),
  is_auto      boolean not null default false,
  extended_clock boolean not null default false,   -- did this bid trigger anti-snipe?
  created_at   timestamptz not null default now()
);
create index bids_auction_idx on public.bids (auction_id, created_at desc);

-- ───────────────────────── auto-bids (proxy max) ─────────────────────────
create table public.auto_bids (
  auction_id   uuid references public.auctions(id) on delete cascade,
  bidder_id    uuid references public.users(id),
  max_cents    bigint not null check (max_cents > 0),
  primary key (auction_id, bidder_id)
);

-- ───────────────────────── payouts (royalty split) ─────────────────────────
create table public.payouts (
  id            uuid primary key default gen_random_uuid(),
  auction_id    uuid not null references public.auctions(id),
  payee_id      uuid not null references public.users(id),
  role          text not null check (role in ('artist', 'seller', 'platform')),
  amount_cents  bigint not null,
  created_at    timestamptz not null default now()
);

-- ───────────────────────── place_bid(): atomic + anti-sniping ─────────────────────────
-- Call from a Next.js Route Handler / Server Action via supabase.rpc('place_bid', ...).
-- The row lock prevents two simultaneous bids from both winning.
create or replace function public.place_bid(p_auction_id uuid, p_amount_cents bigint)
returns public.bids
language plpgsql
security definer
set search_path = public
as $$
declare
  a        public.auctions;
  uid      uuid := auth.uid();
  new_end  timestamptz;
  extended boolean := false;
  b        public.bids;
begin
  if uid is null then raise exception 'not_authenticated'; end if;

  select * into a from public.auctions where id = p_auction_id for update;
  if not found then raise exception 'auction_not_found'; end if;
  if a.status <> 'live' or now() >= a.ends_at then raise exception 'auction_closed'; end if;
  if a.seller_id = uid then raise exception 'seller_cannot_bid'; end if;
  if a.highest_bidder_id = uid then raise exception 'already_highest_bidder'; end if;
  if p_amount_cents < a.current_price_cents + a.min_increment_cents
     and a.bid_count > 0 then
    raise exception 'bid_too_low';
  end if;
  if a.bid_count = 0 and p_amount_cents < a.starting_price_cents then
    raise exception 'bid_below_start';
  end if;

  -- Soft close: bid inside the window resets the clock to snipe_extend_to_secs.
  new_end := a.ends_at;
  if a.ends_at - now() <= make_interval(secs => a.snipe_window_secs) then
    new_end := now() + make_interval(secs => a.snipe_extend_to_secs);
    extended := true;
  end if;

  insert into public.bids (auction_id, bidder_id, amount_cents, extended_clock)
  values (p_auction_id, uid, p_amount_cents, extended)
  returning * into b;

  update public.auctions
     set current_price_cents = p_amount_cents,
         highest_bidder_id   = uid,
         bid_count           = bid_count + 1,
         ends_at             = new_end
   where id = p_auction_id;

  return b;
end;
$$;

-- ───────────────────────── Row Level Security ─────────────────────────
alter table public.users    enable row level security;
alter table public.artworks enable row level security;
alter table public.auctions enable row level security;
alter table public.bids     enable row level security;
alter table public.auto_bids enable row level security;

create policy "public read users"    on public.users    for select using (true);
create policy "public read artworks" on public.artworks for select using (true);
create policy "public read auctions" on public.auctions for select using (true);
create policy "public read bids"     on public.bids     for select using (true);
create policy "own auto_bids"        on public.auto_bids for all using (bidder_id = auth.uid());
-- No insert/update policy on bids or auctions: all writes go through place_bid().

-- ───────────────────────── Realtime ─────────────────────────
alter publication supabase_realtime add table public.bids;
alter publication supabase_realtime add table public.auctions;
