"use client";
// Drop-in demo: copy to app/page.tsx. Runs with no backend.
// Local state stands in for Supabase; rivals bid randomly so you can see
// the ticker, outbid alert, and anti-sniping extension working.
import { useEffect, useState } from "react";
import LiveArtworkBidCard from "@/components/LiveArtworkBidCard";
import BiddingColumn from "@/components/BiddingColumn";
import { mockAuctions, mockBidsFor, bidders } from "@/lib/mock-data";
import type { Auction, Bid } from "@/lib/types";

const ME = bidders.find((b) => b.id === "me")!;

export default function Home() {
  const [auctions, setAuctions] = useState<Auction[]>(mockAuctions);
  const [bids, setBids] = useState<Record<string, Bid[]>>(() =>
    Object.fromEntries(mockAuctions.map((a) => [a.id, mockBidsFor(a.id)]))
  );
  const [focusId, setFocusId] = useState(mockAuctions[0].id);

  function applyBid(auctionId: string, bidder: Auction["highestBidder"], amountCents: number) {
    setAuctions((prev) =>
      prev.map((a) => {
        if (a.id !== auctionId) return a;
        const msLeft = new Date(a.endsAt).getTime() - Date.now();
        if (msLeft <= 0) throw new Error("auction closed");
        if (a.highestBidder?.id === bidder!.id) throw new Error("already highest bidder");
        if (amountCents < a.currentPriceCents + a.minIncrementCents) throw new Error("bid too low");
        const extend = msLeft <= a.snipeWindowSecs * 1000;
        const endsAt = extend ? new Date(Date.now() + a.snipeExtendToSecs * 1000).toISOString() : a.endsAt;
        const bid: Bid = {
          id: crypto.randomUUID(), auctionId, bidder: bidder!, amountCents,
          extendedClock: extend, createdAt: new Date().toISOString(),
        };
        setBids((b) => ({ ...b, [auctionId]: [bid, ...(b[auctionId] ?? [])].slice(0, 50) }));
        return { ...a, currentPriceCents: amountCents, highestBidder: bidder, bidCount: a.bidCount + 1, endsAt };
      })
    );
  }

  // Simulated rivals.
  useEffect(() => {
    const t = setInterval(() => {
      const live = auctions.filter((a) => new Date(a.endsAt).getTime() > Date.now());
      if (!live.length) return;
      const a = live[Math.floor(Math.random() * live.length)];
      const rival = bidders[Math.floor(Math.random() * 4)];
      try { applyBid(a.id, rival, a.currentPriceCents + a.minIncrementCents); } catch {}
    }, 4000);
    return () => clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [auctions]);

  const onBid = async (auctionId: string, cents: number) => applyBid(auctionId, ME, cents);
  const focus = auctions.find((a) => a.id === focusId)!;

  return (
    <main className="min-h-screen bg-[#07070d] p-6 text-zinc-100">
      <section className="mx-auto mb-10 grid max-w-6xl gap-6 lg:grid-cols-[1.1fr_1fr]">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={focus.artwork.previewUrl} alt={focus.artwork.title} className="w-full rounded-3xl object-cover" />
        <BiddingColumn
          auction={focus} bids={bids[focus.id] ?? []} currentUserId={ME.id}
          onBid={(c) => onBid(focus.id, c)} onSetAutoBid={async () => {}}
        />
      </section>

      <section className="mx-auto grid max-w-6xl gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {auctions.map((a) => (
          <div key={a.id} onClickCapture={() => setFocusId(a.id)}>
            <LiveArtworkBidCard auction={a} currentUserId={ME.id} onBid={onBid} />
          </div>
        ))}
      </section>
    </main>
  );
}
