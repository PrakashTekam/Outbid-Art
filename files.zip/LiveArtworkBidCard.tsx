"use client";
import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { animate, motion, useMotionValue, useTransform } from "framer-motion";
import { BadgeCheck, Gavel, ShieldAlert, Timer } from "lucide-react";
import { useCountdown } from "@/hooks/useCountdown";
import { formatUsd, type Auction } from "@/lib/types";

/** Rolling number ticker. Animates between values whenever `cents` changes. */
export function PriceTicker({ cents, className = "" }: { cents: number; className?: string }) {
  const mv = useMotionValue(cents);
  const text = useTransform(mv, (v) => formatUsd(Math.round(v)));
  useEffect(() => {
    const controls = animate(mv, cents, { duration: 0.5, ease: "easeOut" });
    return () => controls.stop();
  }, [cents, mv]);
  return <motion.span className={`tabular-nums ${className}`}>{text}</motion.span>;
}

interface Props {
  auction: Auction;
  /** Called with the absolute bid amount in cents. Should reject on failure. */
  onBid: (auctionId: string, amountCents: number) => Promise<void>;
  currentUserId?: string;
  serverOffsetMs?: number;
}

const PRESETS_CENTS = [500, 2500, 10000]; // +$5, +$25, +$100

export default function LiveArtworkBidCard({ auction, onBid, currentUserId, serverOffsetMs = 0 }: Props) {
  const { artwork, highestBidder } = auction;
  const clock = useCountdown(auction.endsAt, serverOffsetMs, auction.snipeWindowSecs);
  const [custom, setCustom] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [flash, setFlash] = useState(false);
  const prevPrice = useRef(auction.currentPriceCents);

  const iAmWinning = !!currentUserId && highestBidder?.id === currentUserId;
  const reserveMet = auction.reservePriceCents == null || auction.currentPriceCents >= auction.reservePriceCents;
  const endingSoon = !clock.ended && clock.msLeft <= 60 * 60 * 1000;

  // Flash the card border on every incoming bid.
  useEffect(() => {
    if (auction.currentPriceCents !== prevPrice.current) {
      prevPrice.current = auction.currentPriceCents;
      setFlash(true);
      const t = setTimeout(() => setFlash(false), 700);
      return () => clearTimeout(t);
    }
  }, [auction.currentPriceCents]);

  async function submit(amountCents: number) {
    setError(null);
    setBusy(true);
    try {
      await onBid(auction.id, amountCents);
      setCustom("");
    } catch (e) {
      setError(e instanceof Error ? e.message.replaceAll("_", " ") : "Bid failed");
    } finally {
      setBusy(false);
    }
  }

  // A preset is "current price + preset", but never below the minimum increment.
  const quick = (presetCents: number) =>
    auction.currentPriceCents + Math.max(presetCents, auction.minIncrementCents);

  const customCents = Math.round(parseFloat(custom || "0") * 100);
  const minNext = auction.currentPriceCents + auction.minIncrementCents;
  const customValid = customCents >= minNext;

  return (
    <article
      className={`group relative overflow-hidden rounded-2xl border bg-white/[0.04] backdrop-blur-xl transition-colors duration-300
        ${flash ? "border-cyan-300 shadow-[0_0_32px_-4px_rgba(103,232,249,0.55)]" : "border-white/10"}
        ${clock.urgent ? "shadow-[0_0_36px_-6px_rgba(244,63,94,0.5)]" : ""}`}
    >
      {/* Artwork */}
      <Link href={`/auction/${auction.id}`} className="relative block aspect-[4/5] overflow-hidden bg-black">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={artwork.previewUrl}
          alt={`${artwork.title} by ${artwork.artist.displayName}`}
          className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.06]"
          style={artwork.medium === "pixel_art" ? { imageRendering: "pixelated" } : undefined}
          loading="lazy"
        />
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/30" />

        <div className="absolute left-3 top-3 flex items-center gap-2">
          {clock.ended ? (
            <span className="rounded-full bg-zinc-700/90 px-2.5 py-1 text-xs font-semibold">Ended</span>
          ) : (
            <span className="flex items-center gap-1.5 rounded-full bg-rose-500/90 px-2.5 py-1 text-xs font-bold tracking-wide">
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-white" />
              {endingSoon ? "ENDING SOON" : "LIVE"}
            </span>
          )}
          {reserveMet && auction.reservePriceCents != null && (
            <span className="rounded-full bg-amber-400/90 px-2.5 py-1 text-xs font-semibold text-black">Reserve met</span>
          )}
        </div>

        <div className="absolute inset-x-0 bottom-0 p-4">
          <h3 className="font-display text-xl font-semibold leading-tight text-white drop-shadow">{artwork.title}</h3>
          <p className="mt-1 flex items-center gap-1.5 text-sm text-zinc-300">
            {artwork.artist.displayName}
            {artwork.artist.isVerified && (
              <BadgeCheck className="h-4 w-4 text-cyan-300" aria-label="Verified artist" />
            )}
          </p>
        </div>
      </Link>

      {/* Bid panel */}
      <div className="space-y-3 p-4">
        <div className="flex items-end justify-between gap-3">
          <div>
            <p className="text-xs text-zinc-400">{auction.bidCount === 0 ? "Starting bid" : "Current bid"}</p>
            <PriceTicker cents={auction.currentPriceCents} className="text-2xl font-bold text-amber-300" />
          </div>
          <div className="text-right">
            <p className="text-xs text-zinc-400">Ends in</p>
            <p
              className={`font-mono text-lg tabular-nums ${clock.urgent ? "animate-pulse text-rose-400" : "text-zinc-100"}`}
              aria-live="off"
            >
              {clock.ended ? "00:00:00.000" : clock.label}
            </p>
          </div>
        </div>

        <div className="flex items-center justify-between text-sm">
          {highestBidder ? (
            <span className="flex items-center gap-2">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={highestBidder.avatarUrl} alt="" className="h-6 w-6 rounded-full ring-2 ring-amber-300/70" />
              <span className={iAmWinning ? "font-semibold text-emerald-300" : "text-zinc-200"}>
                {iAmWinning ? "You're winning" : `@${highestBidder.handle}`}
              </span>
            </span>
          ) : (
            <span className="text-zinc-400">No bids yet</span>
          )}
          <span className="flex items-center gap-1 text-xs text-zinc-400" title={`A bid in the last ${auction.snipeWindowSecs}s resets the clock to ${auction.snipeExtendToSecs}s`}>
            <ShieldAlert className="h-3.5 w-3.5 text-indigo-300" />
            +{auction.snipeExtendToSecs}s soft close
          </span>
        </div>

        {/* Quick bids */}
        <div className="grid grid-cols-3 gap-2">
          {PRESETS_CENTS.map((p) => (
            <button
              key={p}
              disabled={busy || clock.ended || iAmWinning}
              onClick={() => submit(quick(p))}
              className="rounded-xl border border-indigo-400/40 bg-indigo-500/15 py-2 text-sm font-semibold text-indigo-100 transition hover:bg-indigo-500/35 focus-visible:outline focus-visible:outline-2 focus-visible:outline-cyan-300 active:scale-95 disabled:cursor-not-allowed disabled:opacity-40"
            >
              +{formatUsd(p)}
            </button>
          ))}
        </div>

        <div className="flex gap-2">
          <label className="sr-only" htmlFor={`custom-${auction.id}`}>Custom bid in dollars</label>
          <input
            id={`custom-${auction.id}`}
            inputMode="decimal"
            value={custom}
            onChange={(e) => setCustom(e.target.value.replace(/[^0-9.]/g, ""))}
            placeholder={`Min ${formatUsd(minNext)}`}
            className="min-w-0 flex-1 rounded-xl border border-white/10 bg-black/40 px-3 py-2 text-sm outline-none focus:border-cyan-300"
          />
          <button
            disabled={busy || clock.ended || !customValid || iAmWinning}
            onClick={() => submit(customCents)}
            className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-indigo-500 to-cyan-400 px-4 py-2 text-sm font-bold text-black transition active:scale-95 disabled:cursor-not-allowed disabled:opacity-40"
          >
            <Gavel className="h-4 w-4" />
            Place bid
          </button>
        </div>

        {error && <p role="alert" className="text-sm text-rose-400">{error}</p>}
        {clock.urgent && !clock.ended && (
          <p className="flex items-center gap-1.5 text-xs text-rose-300">
            <Timer className="h-3.5 w-3.5" /> Final seconds. A new bid extends the clock.
          </p>
        )}
      </div>
    </article>
  );
}
