"use client";
import { useEffect, useRef, useState } from "react";

export interface Countdown {
  msLeft: number;
  ended: boolean;
  /** HH:MM:SS.ms, e.g. "01:02:03.450" */
  label: string;
  /** true in the final `urgentSecs` seconds */
  urgent: boolean;
}

const pad = (n: number, w = 2) => String(n).padStart(w, "0");

export function formatCountdown(ms: number) {
  const t = Math.max(0, ms);
  const h = Math.floor(t / 3_600_000);
  const m = Math.floor((t % 3_600_000) / 60_000);
  const s = Math.floor((t % 60_000) / 1000);
  const msPart = Math.floor(t % 1000);
  return `${pad(h)}:${pad(m)}:${pad(s)}.${pad(msPart, 3)}`;
}

/**
 * Counts down to `endsAt` (ISO string). Re-syncs automatically when `endsAt`
 * changes, which is how anti-sniping extensions arrive from the server.
 *
 * `serverOffsetMs` = serverNow - clientNow. Measure it once (e.g. from a
 * response `Date` header or a Supabase `select now()`) so a wrong device clock
 * can't show the wrong time.
 */
export function useCountdown(endsAt: string, serverOffsetMs = 0, urgentSecs = 10): Countdown {
  const target = new Date(endsAt).getTime();
  const [msLeft, setMsLeft] = useState(() => target - (Date.now() + serverOffsetMs));
  const raf = useRef<number>(0);

  useEffect(() => {
    const tick = () => {
      const left = target - (Date.now() + serverOffsetMs);
      setMsLeft(left);
      if (left > 0) raf.current = requestAnimationFrame(tick);
    };
    raf.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf.current);
  }, [target, serverOffsetMs]);

  return {
    msLeft,
    ended: msLeft <= 0,
    label: formatCountdown(msLeft),
    urgent: msLeft > 0 && msLeft <= urgentSecs * 1000,
  };
}
