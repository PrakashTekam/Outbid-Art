export type Medium =
  | "3d_render"
  | "digital_painting"
  | "pixel_art"
  | "vector"
  | "concept_art"
  | "canvas_print";

export interface Artist {
  id: string;
  handle: string;
  displayName: string;
  avatarUrl: string;
  isVerified: boolean;
  bio?: string;
  pastSalesCount?: number;
}

export interface Bidder {
  id: string;
  handle: string;
  avatarUrl: string;
}

export interface Artwork {
  id: string;
  title: string;
  medium: Medium;
  previewUrl: string;
  widthPx: number;
  heightPx: number;
  fileFormat: string;
  editionNumber: number;
  editionSize: number;
  licenseType: string;
  certificateIssued: boolean;
  royaltyBps: number;
  artist: Artist;
}

export interface Auction {
  id: string;
  artwork: Artwork;
  /** All money values are integer cents to avoid float errors. */
  currentPriceCents: number;
  minIncrementCents: number;
  reservePriceCents: number | null;
  highestBidder: Bidder | null;
  bidCount: number;
  /** ISO timestamp. Updated by the server whenever anti-sniping fires. */
  endsAt: string;
  snipeWindowSecs: number;
  snipeExtendToSecs: number;
  isFeatured?: boolean;
}

export interface Bid {
  id: string;
  auctionId: string;
  bidder: Bidder;
  amountCents: number;
  isAuto?: boolean;
  extendedClock?: boolean;
  createdAt: string;
}

export const formatUsd = (cents: number) =>
  new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: cents % 100 === 0 ? 0 : 2,
  }).format(cents / 100);
