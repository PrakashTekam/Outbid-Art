import type { Auction, Artist, Bid, Bidder } from "./types";

// Placeholder images come from picsum.photos (seeded, so they stay stable).
// Swap for your own watermarked previews; if you use next/image, add the host to next.config.js.
const img = (seed: string, w = 1200, h = 1500) =>
  `https://picsum.photos/seed/${seed}/${w}/${h}`;
const avatar = (seed: string) => `https://i.pravatar.cc/120?u=${seed}`;

const inMs = (ms: number) => new Date(Date.now() + ms).toISOString();
const MIN = 60_000;
const HOUR = 60 * MIN;

export const artists: Record<string, Artist> = {
  mira: {
    id: "a1", handle: "mirakova", displayName: "Mira Kova",
    avatarUrl: avatar("mirakova"), isVerified: true, pastSalesCount: 42,
    bio: "Digital painter blending oil-brush textures with generative light.",
  },
  teo: {
    id: "a2", handle: "teo.vox", displayName: "Teo Vasquez",
    avatarUrl: avatar("teovox"), isVerified: true, pastSalesCount: 17,
    bio: "3D environment artist exploring brutalist dreamscapes.",
  },
  nox: {
    id: "a3", handle: "noxpixel", displayName: "Nox Pixel",
    avatarUrl: avatar("noxpixel"), isVerified: false, pastSalesCount: 5,
    bio: "Pixel artist. 64x64 canvases, maximal feeling.",
  },
  sana: {
    id: "a4", handle: "sana_ink", displayName: "Sana Iyer",
    avatarUrl: avatar("sanaink"), isVerified: true, pastSalesCount: 29,
    bio: "Vector illustrator working in flat color and bold geometry.",
  },
};

export const bidders: Bidder[] = [
  { id: "u1", handle: "gallery_ghost", avatarUrl: avatar("galleryghost") },
  { id: "u2", handle: "lumen.collects", avatarUrl: avatar("lumen") },
  { id: "u3", handle: "bidzilla", avatarUrl: avatar("bidzilla") },
  { id: "u4", handle: "quietmoney", avatarUrl: avatar("quietmoney") },
  { id: "me", handle: "you", avatarUrl: avatar("me") },
];

export const mockAuctions: Auction[] = [
  {
    id: "auc-1",
    isFeatured: true,
    artwork: {
      id: "art-1", title: "Tidal Cathedral", medium: "digital_painting",
      previewUrl: img("tidal-cathedral"), widthPx: 8000, heightPx: 10000,
      fileFormat: "TIFF (16-bit)", editionNumber: 1, editionSize: 1,
      licenseType: "Personal display + resale", certificateIssued: true,
      royaltyBps: 1000, artist: artists.mira,
    },
    currentPriceCents: 184_000, minIncrementCents: 5_000, reservePriceCents: 150_000,
    highestBidder: bidders[0], bidCount: 23, endsAt: inMs(2 * HOUR + 14 * MIN),
    snipeWindowSecs: 15, snipeExtendToSecs: 30,
  },
  {
    id: "auc-2",
    artwork: {
      id: "art-2", title: "Concrete Lullaby", medium: "3d_render",
      previewUrl: img("concrete-lullaby"), widthPx: 6000, heightPx: 4000,
      fileFormat: "PNG + .blend source", editionNumber: 3, editionSize: 10,
      licenseType: "Personal display", certificateIssued: true,
      royaltyBps: 750, artist: artists.teo,
    },
    currentPriceCents: 62_500, minIncrementCents: 2_500, reservePriceCents: 50_000,
    highestBidder: bidders[2], bidCount: 11, endsAt: inMs(38 * MIN),
    snipeWindowSecs: 15, snipeExtendToSecs: 30,
  },
  {
    id: "auc-3",
    artwork: {
      id: "art-3", title: "Last Train, 3 A.M.", medium: "pixel_art",
      previewUrl: img("last-train", 1000, 1000), widthPx: 64, heightPx: 64,
      fileFormat: "PNG + GIF loop", editionNumber: 1, editionSize: 1,
      licenseType: "Personal display", certificateIssued: false,
      royaltyBps: 500, artist: artists.nox,
    },
    currentPriceCents: 8_000, minIncrementCents: 500, reservePriceCents: null,
    highestBidder: bidders[1], bidCount: 6, endsAt: inMs(45_000),
    snipeWindowSecs: 15, snipeExtendToSecs: 30,
  },
  {
    id: "auc-4",
    artwork: {
      id: "art-4", title: "Field Notes on Orange", medium: "vector",
      previewUrl: img("field-notes", 1200, 1200), widthPx: 5000, heightPx: 5000,
      fileFormat: "SVG + PDF", editionNumber: 2, editionSize: 5,
      licenseType: "Commercial (editorial)", certificateIssued: true,
      royaltyBps: 1000, artist: artists.sana,
    },
    currentPriceCents: 31_000, minIncrementCents: 1_000, reservePriceCents: 40_000,
    highestBidder: bidders[3], bidCount: 9, endsAt: inMs(6 * HOUR),
    snipeWindowSecs: 15, snipeExtendToSecs: 30,
  },
  {
    id: "auc-5",
    artwork: {
      id: "art-5", title: "Hollow Sun Study", medium: "concept_art",
      previewUrl: img("hollow-sun", 1400, 900), widthPx: 7000, heightPx: 4500,
      fileFormat: "PSD (layered)", editionNumber: 1, editionSize: 1,
      licenseType: "Personal display + resale", certificateIssued: true,
      royaltyBps: 1200, artist: artists.mira,
    },
    currentPriceCents: 45_000, minIncrementCents: 2_500, reservePriceCents: 45_000,
    highestBidder: bidders[0], bidCount: 14, endsAt: inMs(12 * MIN),
    snipeWindowSecs: 15, snipeExtendToSecs: 30,
  },
  {
    id: "auc-6",
    artwork: {
      id: "art-6", title: "Salt Flat Triptych", medium: "canvas_print",
      previewUrl: img("salt-flat", 1200, 1600), widthPx: 9000, heightPx: 12000,
      fileFormat: "TIFF + physical canvas 90x120cm", editionNumber: 4, editionSize: 8,
      licenseType: "Personal display", certificateIssued: true,
      royaltyBps: 800, artist: artists.teo,
    },
    currentPriceCents: 97_500, minIncrementCents: 5_000, reservePriceCents: 80_000,
    highestBidder: null, bidCount: 0, endsAt: inMs(23 * HOUR),
    snipeWindowSecs: 15, snipeExtendToSecs: 30,
  },
];

/** Seed bid history for one auction so the feed isn't empty on first render. */
export function mockBidsFor(auctionId: string): Bid[] {
  const a = mockAuctions.find((x) => x.id === auctionId);
  if (!a || a.bidCount === 0) return [];
  const n = Math.min(a.bidCount, 8);
  return Array.from({ length: n }, (_, i) => ({
    id: `${auctionId}-bid-${i}`,
    auctionId,
    bidder: bidders[(i + 1) % 4],
    amountCents: a.currentPriceCents - i * a.minIncrementCents,
    createdAt: new Date(Date.now() - (i + 1) * 47_000).toISOString(),
  })).map((b, i) => (i === 0 && a.highestBidder ? { ...b, bidder: a.highestBidder } : b));
}
